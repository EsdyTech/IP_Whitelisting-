<?php
$con=mysqli_connect("localhost", "root", "", "ipwhitelisting");
if(mysqli_connect_errno()){
    echo "Connection Fail".mysqli_connect_error(); 
}

// $con=mysqli_connect("localhost", "id18733268_ipwhitelisting_user", "!#vZR8xX/emaGhID", "id18733268_ipwhitelisting");
// if(mysqli_connect_errno()){
//     echo "Connection Fail".mysqli_connect_error(); 
// }

?>